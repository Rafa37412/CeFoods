## CeFoods

To run the devserver:
```
npm install
npm run dev
```
